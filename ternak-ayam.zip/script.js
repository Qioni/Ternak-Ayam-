window.onload = () => {
  console.log("Halaman profil usaha telah dimuat.");
};